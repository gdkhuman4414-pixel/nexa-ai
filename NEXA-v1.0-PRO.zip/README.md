# NEXA v1.0 PRO
Professional foundation for an AI Business Operating System.

Includes:
- FastAPI modular backend
- Secure Argon2 password hashing
- JWT authentication
- Multi-tenant organization/membership model
- CRM, sales, finance, inventory, team and AI-action foundations
- AI orchestration/provider abstraction
- Audit logging
- API validation and tests
- Responsive blue NEXA frontend
- Floating NEXA AI available from every authenticated page

Local development uses SQLite. Production should use PostgreSQL, Redis, object storage, managed secrets, HTTPS, migrations, monitoring and a real AI provider.

Run:
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000

Test:
pytest -q

API docs: /docs
Health: /health
