import os
os.environ["DATABASE_URL"]="sqlite:///./qa_nexa.db"
os.environ["JWT_SECRET"]="qa-secret"
from fastapi.testclient import TestClient
from app.main import app
c=TestClient(app)
def test_health(): assert c.get("/health").json()["status"]=="ok"
def test_signup_me_ai():
    p={"name":"QA","business_name":"QA Business","email":"qa@nexa.local","password":"StrongPass123!"}
    r=c.post("/api/v1/auth/signup",json=p);assert r.status_code in (200,409)
    if r.status_code==409:
        r=c.post("/api/v1/auth/login",json={"email":p["email"],"password":p["password"]})
    token=r.json()["access_token"];h={"Authorization":"Bearer "+token}
    assert c.get("/api/v1/me",headers=h).status_code==200
    r=c.post("/api/v1/ai/chat",headers=h,json={"message":"How is my business doing?"})
    assert r.status_code==200 and "Business snapshot" in r.json()["answer"]
