from pydantic import BaseModel, EmailStr, Field
class SignupIn(BaseModel):
    name:str=Field(min_length=1,max_length=120)
    business_name:str=Field(min_length=1,max_length=160)
    email:EmailStr
    password:str=Field(min_length=8,max_length=128)
class LoginIn(BaseModel):
    email:EmailStr
    password:str=Field(min_length=1,max_length=128)
class TokenOut(BaseModel):
    access_token:str
    token_type:str="bearer"
