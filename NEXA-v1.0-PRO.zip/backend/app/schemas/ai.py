from pydantic import BaseModel, Field
class ChatIn(BaseModel): message:str=Field(min_length=1,max_length=8000)
class ChatOut(BaseModel): answer:str; provider:str; actions:list[dict]=[]
class ActionDecision(BaseModel): decision:str=Field(pattern="^(approve|reject)$")
