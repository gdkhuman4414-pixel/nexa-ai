from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.db.session import engine,Base
from app.api import auth,me,ai
app=FastAPI(title="NEXA AI Business Operating System",version="1.0.0")
app.add_middleware(CORSMiddleware,allow_origins=settings.cors_list,allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
@app.on_event("startup")
def startup(): Base.metadata.create_all(bind=engine)
@app.get("/health")
def health(): return {"status":"ok","service":"nexa-api"}
@app.get("/ready")
def ready(): return {"status":"ready"}
app.include_router(auth.router);app.include_router(me.router);app.include_router(ai.router)
