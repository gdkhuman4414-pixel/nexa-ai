from sqlalchemy.orm import Session
from app.models.models import User,Organization,Membership,AuditLog
from app.core.security import hash_password,verify_password,create_access_token
def signup(db:Session,name,business,email,password):
    if db.query(User).filter(User.email==email).first(): raise ValueError("An account with this email already exists.")
    u=User(name=name,email=email,password_hash=hash_password(password));db.add(u);db.flush()
    o=Organization(name=business,owner_id=u.id);db.add(o);db.flush()
    db.add(Membership(user_id=u.id,organization_id=o.id,role="owner"))
    db.add(AuditLog(organization_id=o.id,user_id=u.id,event="account.created"));db.commit()
    return create_access_token(u.id)
def login(db:Session,email,password):
    u=db.query(User).filter(User.email==email).first()
    if not u or not verify_password(password,u.password_hash): raise ValueError("Invalid email or password.")
    m=db.query(Membership).filter(Membership.user_id==u.id).first()
    db.add(AuditLog(organization_id=m.organization_id if m else None,user_id=u.id,event="auth.login"));db.commit()
    return create_access_token(u.id)
