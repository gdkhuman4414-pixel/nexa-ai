from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.schemas.auth import SignupIn,LoginIn,TokenOut
from app.services.auth import signup,login
router=APIRouter(prefix="/api/v1/auth",tags=["auth"])
@router.post("/signup",response_model=TokenOut)
def create(p:SignupIn,db:Session=Depends(get_db)):
    try:return TokenOut(access_token=signup(db,p.name,p.business_name,p.email.lower(),p.password))
    except ValueError as e:raise HTTPException(409,str(e))
@router.post("/login",response_model=TokenOut)
def auth(p:LoginIn,db:Session=Depends(get_db)):
    try:return TokenOut(access_token=login(db,p.email.lower(),p.password))
    except ValueError as e:raise HTTPException(401,str(e))
