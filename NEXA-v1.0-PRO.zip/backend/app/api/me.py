from fastapi import APIRouter,Depends
from app.core.deps import current_user,current_membership
router=APIRouter(prefix="/api/v1",tags=["account"])
@router.get("/me")
def me(u=Depends(current_user),m=Depends(current_membership)):
    return {"id":u.id,"name":u.name,"email":u.email,"organization_id":m.organization_id,"role":m.role}
