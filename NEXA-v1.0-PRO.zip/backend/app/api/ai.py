import json
from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.orm import Session
from app.core.deps import current_user,current_membership
from app.db.session import get_db
from app.schemas.ai import ChatIn,ChatOut,ActionDecision
from app.ai.engine import AIOrchestrator
from app.models.models import AIAction,AuditLog
router=APIRouter(prefix="/api/v1/ai",tags=["ai"])
ai=AIOrchestrator()
@router.post("/chat",response_model=ChatOut)
def chat(p:ChatIn,u=Depends(current_user),m=Depends(current_membership),db:Session=Depends(get_db)):
    ans=ai.chat(p.message);db.add(AuditLog(organization_id=m.organization_id,user_id=u.id,event="ai.chat",metadata_json=json.dumps({"length":len(p.message)})));db.commit()
    return ChatOut(answer=ans,provider="demo",actions=[])
@router.post("/actions/{action_id}/decision")
def decide(action_id:int,p:ActionDecision,u=Depends(current_user),m=Depends(current_membership),db:Session=Depends(get_db)):
    a=db.get(AIAction,action_id)
    if not a or a.organization_id!=m.organization_id: raise HTTPException(404,"Action not found")
    a.status="approved" if p.decision=="approve" else "rejected";db.commit()
    return {"id":a.id,"status":a.status}
