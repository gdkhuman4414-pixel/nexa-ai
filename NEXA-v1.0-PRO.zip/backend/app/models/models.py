from datetime import datetime, timezone
from sqlalchemy import String, Text, DateTime, ForeignKey, Boolean, Numeric
from sqlalchemy.orm import Mapped, mapped_column
from app.db.session import Base
def now(): return datetime.now(timezone.utc)

class User(Base):
    __tablename__="users"
    id:Mapped[int]=mapped_column(primary_key=True)
    name:Mapped[str]=mapped_column(String(120))
    email:Mapped[str]=mapped_column(String(320),unique=True,index=True)
    password_hash:Mapped[str]=mapped_column(String(255))
    is_active:Mapped[bool]=mapped_column(Boolean,default=True)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class Organization(Base):
    __tablename__="organizations"
    id:Mapped[int]=mapped_column(primary_key=True)
    name:Mapped[str]=mapped_column(String(160))
    owner_id:Mapped[int]=mapped_column(ForeignKey("users.id"))

class Membership(Base):
    __tablename__="memberships"
    id:Mapped[int]=mapped_column(primary_key=True)
    user_id:Mapped[int]=mapped_column(ForeignKey("users.id"),index=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    role:Mapped[str]=mapped_column(String(40),default="owner")

class Customer(Base):
    __tablename__="customers"
    id:Mapped[int]=mapped_column(primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    name:Mapped[str]=mapped_column(String(160))
    email:Mapped[str|None]=mapped_column(String(320),nullable=True)
    phone:Mapped[str|None]=mapped_column(String(40),nullable=True)
    status:Mapped[str]=mapped_column(String(40),default="active")
    lifetime_value:Mapped[float]=mapped_column(Numeric(14,2),default=0)

class Product(Base):
    __tablename__="products"
    id:Mapped[int]=mapped_column(primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    name:Mapped[str]=mapped_column(String(160))
    sku:Mapped[str|None]=mapped_column(String(80),nullable=True)
    stock:Mapped[float]=mapped_column(Numeric(14,2),default=0)
    reorder_level:Mapped[float]=mapped_column(Numeric(14,2),default=0)

class Invoice(Base):
    __tablename__="invoices"
    id:Mapped[int]=mapped_column(primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    invoice_number:Mapped[str]=mapped_column(String(80))
    amount:Mapped[float]=mapped_column(Numeric(14,2),default=0)
    status:Mapped[str]=mapped_column(String(40),default="open")

class AIAction(Base):
    __tablename__="ai_actions"
    id:Mapped[int]=mapped_column(primary_key=True)
    organization_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"),index=True)
    created_by:Mapped[int]=mapped_column(ForeignKey("users.id"))
    action_type:Mapped[str]=mapped_column(String(100))
    payload:Mapped[str]=mapped_column(Text)
    status:Mapped[str]=mapped_column(String(30),default="pending")
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class AuditLog(Base):
    __tablename__="audit_logs"
    id:Mapped[int]=mapped_column(primary_key=True)
    organization_id:Mapped[int|None]=mapped_column(ForeignKey("organizations.id"),nullable=True)
    user_id:Mapped[int|None]=mapped_column(ForeignKey("users.id"),nullable=True)
    event:Mapped[str]=mapped_column(String(160))
    metadata_json:Mapped[str]=mapped_column(Text,default="{}")
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
