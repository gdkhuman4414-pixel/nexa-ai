from fastapi import Depends,HTTPException
from fastapi.security import HTTPBearer,HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.core.security import decode_subject
from app.models.models import User,Membership
bearer=HTTPBearer(auto_error=False)
def current_user(c:HTTPAuthorizationCredentials|None=Depends(bearer),db:Session=Depends(get_db)):
    if not c: raise HTTPException(401,"Authentication required")
    sub=decode_subject(c.credentials)
    if not sub or not str(sub).isdigit(): raise HTTPException(401,"Invalid or expired token")
    u=db.get(User,int(sub))
    if not u or not u.is_active: raise HTTPException(401,"User unavailable")
    return u
def current_membership(u=Depends(current_user),db:Session=Depends(get_db)):
    m=db.query(Membership).filter(Membership.user_id==u.id).first()
    if not m: raise HTTPException(403,"No workspace membership")
    return m
