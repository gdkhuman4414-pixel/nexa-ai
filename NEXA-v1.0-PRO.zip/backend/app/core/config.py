from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "sqlite:///./nexa.db"
    jwt_secret: str = "CHANGE_THIS_IN_PRODUCTION"
    access_token_minutes: int = 60
    cors_origins: str = "http://127.0.0.1:5500,http://localhost:5500"
    ai_provider: str = "demo"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    @property
    def cors_list(self): return [x.strip() for x in self.cors_origins.split(",") if x.strip()]
settings = Settings()
