from datetime import datetime,timedelta,timezone
from jose import jwt,JWTError
from pwdlib import PasswordHash
from app.core.config import settings
ph=PasswordHash.recommended()
def hash_password(p): return ph.hash(p)
def verify_password(p,h):
    try:return ph.verify(p,h)
    except Exception:return False
def create_access_token(sub):
    exp=datetime.now(timezone.utc)+timedelta(minutes=settings.access_token_minutes)
    return jwt.encode({"sub":str(sub),"exp":exp},settings.jwt_secret,algorithm="HS256")
def decode_subject(token):
    try:return jwt.decode(token,settings.jwt_secret,algorithms=["HS256"]).get("sub")
    except JWTError:return None
