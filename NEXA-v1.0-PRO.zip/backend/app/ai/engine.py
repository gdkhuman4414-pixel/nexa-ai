class DemoAI:
    def chat(self,q):
        q=q.lower().strip()
        if any(x in q for x in ["business doing","business performance","summary","how are things"]):
            return "Business snapshot: revenue ₹12.8L, expenses ₹8.8L, profit ₹4.0L, 1,284 customers and ₹2.4L receivables. Main attention items are customer follow-ups, upcoming invoices and Product A."
        if any(x in q for x in ["focus","today","attention","priority"]):
            return "Today: review the 7 high-value customer follow-ups, 3 invoices approaching their due dates, and Product A because demand is rising."
        if any(x in q for x in ["revenue","profit","money"]):
            return "Demo financial snapshot: revenue ₹12.8L, expenses ₹8.8L, profit ₹4.0L and receivables ₹2.4L."
        if "customer" in q or "client" in q: return "1,284 demo customers are tracked, with 7 high-value accounts flagged for follow-up."
        if "sales" in q or "order" in q: return "Demo sales: ₹12.8L sales, 486 orders, ₹18.4L pipeline and 12.6% conversion."
        if "invoice" in q or "due" in q: return "Three demo invoices need attention. INV-1042 is due in 2 days for ₹84,000."
        if "product" in q or "stock" in q or "inventory" in q: return "Product A has rising demand and is flagged for a restock review."
        return "Try asking: “How is my business doing?”, “What should I focus on today?”, or “How are sales?”"
class AIOrchestrator:
    def __init__(self): self.engine=DemoAI()
    def chat(self,message): return self.engine.chat(message)
