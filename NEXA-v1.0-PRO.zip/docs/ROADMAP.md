# NEXA Roadmap
Foundation: authentication, tenant model, AI abstraction, audit, responsive UI.
Next: PostgreSQL migrations, Redis, object storage, full CRM/sales/finance/inventory CRUD, document OCR/RAG.
Then: real model provider, streaming, memory, tool calling, planning, integrations and automation.
Before production: security review, dependency scanning, rate limits, load tests, monitoring, backups, disaster recovery, privacy controls and CI/CD.
