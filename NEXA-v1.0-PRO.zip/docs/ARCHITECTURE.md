# NEXA Architecture
Frontend -> HTTPS -> FastAPI -> Domain services -> PostgreSQL/Redis/Object Storage/AI provider.

Domains: identity, organizations, RBAC, CRM, sales, finance, inventory, team, marketing, documents, analytics, AI orchestration, tools, approvals, automations, notifications, integrations, audit.

Business facts should come from database/services. Analytics calculates metrics. AI explains and plans. Tools perform controlled operations. Consequential actions require approval.
